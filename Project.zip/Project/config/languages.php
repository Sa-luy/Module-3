<?php
return [
    'en' => 'English',
    'vi' => 'Việt Nam',
];
?>