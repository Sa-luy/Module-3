<?php
return [
    'access'=>[
        'user-view'=>'user_view',
        
    ],
    'table'=>[
        'product'=>'Sản Phẩm',
        'category'=>'Danh mục sản phẩm',
        'role'=>'Role',
        'user'=>'Người dùng',
        'order'=>'Đơn hàng',
        'order_detail'=>'Chi tiết đơn hàng',
        'customers' => 'Khách Hàng'
        
    ],
    'action'=>[
        'viewAll'=>'Xem tất cả',
        'view'=>'Xem chi tiết',
        'add'=>'Thêm mới',
        'edit'=>'Chỉnh Sửa',
        'delete'=>'Xóa',
        'restore'=>'khôi phục',
        'forceDelete' =>'Xóa vĩnh viễn',
    ]
];
?>