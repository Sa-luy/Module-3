;
<?php $__env->startSection('content'); ?>
    <div>
        <h3>User List</h3>
        <div class="row">
            <div class="col">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', App\models\User::class)): ?>
                    <a href="<?php echo e(route('user.create')); ?>" class="btn btn-primary ">Add</a>
                <?php endif; ?>
            </div>
            <div class="col">
                <?php if(Session::has('success')): ?>
                    <p style="color: blue"><?php echo e(Session::get('success')); ?></p>
                <?php endif; ?>
            </div>
            <div class="col">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', App\models\User::class)): ?>
                <a href="<?php echo e(route('user-trashed')); ?>"> <button type="subit" class="btn btn-labeled btn-danger">
                        <span class="btn-label"><i class="fa fa-trash"></i>Trash</span>
                    </button>
                </a>
                <?php endif; ?>
            </div>



        </div>
        <table class="table table-striped-columns">
            <thead>
                <tr>
                    <td>#</td>
                    <td>Name</td>
                    <td>Email</td>
                    <td> Phone</td>
                    <td> Action</td>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($key); ?></a> </td>
                        <td> <?php echo e($user->name); ?></a></td>
                        <td> <?php echo e($user->email); ?></a></td>
                        <td><?php echo e($user->phone); ?></a></td>
                        <td>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', App\models\User::class)): ?>
                                <a href="<?php echo e(route('user.edit', $user->id)); ?>" class="btn btn-info sm">
                                    <i class="fas fa-edit "></i>
                                </a>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', App\models\User::class)): ?>
                                <a data-href="<?php echo e(route('user.destroy', $user->id)); ?>" id="<?php echo e($user->id); ?>"
                                    class="btn btn-danger sm deleteIcon"><i class=" fas fa-trash-alt "></i>
                                </a>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view', App\models\User::class)): ?>
                                <a href="<?php echo e(route('user.show', $user->id)); ?>" class="btn btn-primary waves-effect waves-light">
                                    <i class="fa-solid fa-eye"></i>
                                </a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>

        </table>
        <?php echo e($users->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\module3\hoc-lai-m3\Project\resources\views/admin/users/index.blade.php ENDPATH**/ ?>