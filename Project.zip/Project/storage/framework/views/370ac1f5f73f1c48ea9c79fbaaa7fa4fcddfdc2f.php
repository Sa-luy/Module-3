;
<?php $__env->startSection('content'); ?>
<style>
    .form-select{
        padding: 8;
    margin: 0px !important;
    }
</style>
    <h1>Sửa Thông Tin Sản Phẩm </h1>
    <?php $__errorArgs = ['msg'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <h3 style="color: rgb(232, 13, 16); height:40px;" class="alter alert-primary text-center"><?php echo e($message); ?></h3>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <form action="<?php echo e(route('product.update',$product->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <table>
            <tr>
                <td>
                    <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Tên Sản Phẩm</label>
                        <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="name" value="<?php echo e($product->name); ?>">
                        <?php if($errors->any()): ?>
                        <div style="color: red" class="form-text"><?php echo e($errors->first('name')); ?></div>
                        <?php endif; ?>
                    </div>
                </td>
                <td>
                    <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Danh Mục Sản Phẩm</label>
                        <select class="form-select form-select-lg mb-3" aria-label=".form-select-lg example" name="category_id">
                            <option  value="<?php echo e($product->category->id); ?>" selected><?php echo e($product->category->name); ?></option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <
                          </select>
                        
                        
                        <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div style="color: red" class="form-text"><?php echo e($errors->first('category_id')); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </td>
                <td>
                    <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Giá Sản Phẩm</label>
                        <input type="number" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="price" value="<?php echo e($product->price); ?>">
                        <?php if($errors->any()): ?>
                        <div style="color: red" class="form-text"><?php echo e($errors->first('price')); ?></div>
                        <?php endif; ?>
                    </div>
                </td>
            </tr>
            <tr>
                <td>
                    <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Mô tả Sản Phẩm</label>
                        <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="description" value="<?php echo e($product->description); ?>">
                        <?php if($errors->any()): ?>
                        <div style="color: red" class="form-text"><?php echo e($errors->first('description')); ?></div>
                        <?php endif; ?>
                    </div>
                </td>
                <td>
                    <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Công Dụng</label>
                        <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"  name="use" value="<?php echo e($product->use); ?>">
                        <?php if($errors->any()): ?>
                        <div style="color: red" class="form-text"><?php echo e($errors->first('use')); ?></div>
                        <?php endif; ?>
                    </div>
                </td>
            </tr>
            <tr>
                <td>
                    <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Số Lượng Hiện Có</label>
                        <input type="number" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="amouth" value="<?php echo e($product->amouth); ?>">
                        <?php if($errors->any()): ?>
                        <div style="color: red" class="form-text"><?php echo e($errors->first('amouth')); ?></div>
                        <?php endif; ?>
                    </div>
                </td>
                <td>
                    <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Phụ lục</label>
                        <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="status" value="<?php echo e($product->status); ?>">
                        <?php if($errors->any()): ?>
                        <div style="color: red" class="form-text"><?php echo e($errors->first('status')); ?></div>
                        <?php endif; ?>
                    </div>
                </td>
            </tr>
        </table>
        <tr>
            <td>
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Hình Ảnh</label>
                    <input type="file" accept="image/*" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="file" style="width: 600px" value="<?php echo e($product->image); ?>">
                    <?php if($errors->any()): ?>
                    <div style="color: red" class="form-text"><?php echo e($errors->first('file')); ?></div>
                   
                    <?php endif; ?>
                    <img src="<?php echo e(asset('storage/images/' . $product->image)); ?>" alt=""
                    style="width: 150px">
                </div>
            </td>

        </tr>


        <button type="submit" class="btn btn-primary">Submit</button>

    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\module3\hoc-lai-m3\Project\resources\views/admin/products/edit.blade.php ENDPATH**/ ?>