;
<?php $__env->startSection('content'); ?>
    <div class="customers">
        <div class="row">
            <div class="col"><form action="<?php echo e(route('import')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="file" name="file" class="form-control">
                <?php if($errors->any()): ?>
                <p style="color:red"><?php echo e($errors->first('file')); ?></p>
            <?php endif; ?>
                <br>
                <button class="btn btn-success">Import User Data</button>
            </form></div>
            <div class="col">
                <?php if(Session::has('messages')): ?>
                <p class="text-danger"><?php echo e(Session::get('success')); ?></p>
                <?php endif; ?>
            </div>
            <div class="col"> <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', \App\Models\Category::class)): ?>
                <a href="<?php echo e(route('customer-trashed')); ?>" class="btn btn-sm btn-danger">
                    <button type="subit" class="btn btn-labeled btn-danger">
                        <span class="btn-label"><i class="fa fa-trash"></i>Đã xóa</span></button></a>
                        <?php endif; ?></div>
        </div>
        <table class="table table-striped">
            <thead>
                <th>#</th>
                <th>Name</th>
                <th>Phone</th>
                <th>Adress</th>
                <th>Email</th>
                <th>Provider</th>
                <th>Action</th>
            </thead>
            <tbody>
                <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($customer->id); ?></td>
                        <td><?php echo e($customer->name); ?></td>
                        <td><?php echo e($customer->phone); ?></td>
                        <td><?php echo e($customer->address); ?></td>
                        <td><?php echo e($customer->email); ?></td>
                        <td><?php echo e($customer->provider_name); ?></td>
                        <td>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view', \App\Models\Customer::class)): ?>
                            <a href="<?php echo e(route('customer.show', $customer->id)); ?>" class="waves-effect waves-light">
                                <i class="fa-solid fa-eye"></i>
                            </a>
                            <?php endif; ?>
                           <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', \App\Models\Customer::class)): ?>
                                 <a href="<?php echo e(route('customer.edit', $customer->id)); ?>" class="">
                                    <i class="fa-solid fa-pen-to-square"></i>
                                </a>
                             <?php endif; ?> 

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', \App\Models\Customer::class)): ?>
                     <a data-url="<?php echo e(route('customer.destroy', $customer->id)); ?>" id="<?php echo e($customer->id); ?>"
                        class="btn btn-warning sm deleteCustomer"><i class=" fas fa-trash-alt "></i>
                    </a> 
                 <?php endif; ?>  
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
  
    $(function() {
        $('.deleteCustomer').on('click', deleteCustomer)
    })

    function deleteCustomer(event) {
        event.preventDefault();
        let url = $(this).data('url');
        let id = $(this).data('id');
        Swal.fire({
            title: "Are you sure delete ?",
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
            if (result.isConfirmed) {
                jQuery.ajax({
                    type: "delete",
                    'url': url,
                    'data': {
                        id: id,
                        _token: "<?php echo e(csrf_token()); ?>",
                    },
                    dataType: 'json',
                    success: function(data, ) {
                        if (data.status === 1) {
                            window.location.reload();
                            alert(data.messages)

                        } 
                        if (data.status === 0) {
                            window.location.reload();
                            alert(data.messages)

                        } 
                        }
                });

            }

        })
    }
</script>

<?php echo $__env->make('admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\module3\hoc-lai-m3\Project\resources\views/admin/customers/index.blade.php ENDPATH**/ ?>