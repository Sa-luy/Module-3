;
<?php $__env->startSection('content'); ?>


    <div class="row">
        <div class="col-6">
            <h2>Danh Sách Sản Phẩm Đã Xóa</h2>
        </div>
        <div class="col">
            <?php if(Session::has('success')): ?>
                <p class="text-success">
                    <i class="fa fa-check" aria-hidden="true"></i><?php echo e(Session::get('success')); ?>

                </p>
            <?php endif; ?>
        </div>

        <div class="col">

        </div>
    </div>
    <?php if(count($producs_trasheds) == 0): ?>
        <p>Chưa có Sản Phẩm đã xóa</p>
    <?php else: ?>
        <table class="table table-hover">
            
            <thead>
                <tr>
                    <th>#</th>
                    <th><?php echo e(__('lang.name-product')); ?></th>
                    <th><?php echo e(__('lang.price')); ?></th>
                    <th><?php echo e(__('lang.quantity')); ?></th>
                    <th><?php echo e(__('lang.category-name')); ?></th>
                    <th><?php echo e(__('lang.image-list')); ?></th>
                    <th><?php echo e(__('lang.description')); ?></th>
                    <th><?php echo e(__('lang.use')); ?></th>
                    <th><?php echo e(__('lang.appendix')); ?></th>
                    <th><?php echo e(__('lang.action')); ?></th>
                </tr>


                <?php $__currentLoopData = $producs_trasheds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="table-dark">
                        <td class="text-center"><?php echo e($product->id); ?></td>
                        <td><?php echo e($product->name); ?></td>
                        <td><?php echo e($product->price); ?></td>
                        <td><?php echo e($product->amouth); ?></td>
                        <td><?php echo e($product->category->name ?? 'chưa nhập danh mục'); ?></td>
                        <td>
                            <img src="<?php echo e(asset('storage/images/' . $product->image)); ?>" alt=""
                                style="width: 150px">
                        </td>
                        <td class="word_break"><?php echo e($product->description); ?></td>
                        <td><?php echo e($product->use); ?></td>
                        <td><?php echo e($product->status); ?></td>
                        <td>
                            
                            <form action="<?php echo e(route('admin.product.restore', $product->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <button class="btn btn-success align-middle" type="submit"
                                    onclick="return confirm('Bạn muốn khôi phục <?php echo e($product->name); ?> ?')">
                                    <i class='bx bxs-trash'></i>
                                </button>
                            </form>
                            <form action="<?php echo e(route('product-force-delete', $product->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <button class="btn btn-danger align-middle" type="submit"
                                    onclick="return confirm('Bạn muốn xóa vĩnh viễn  <?php echo e($product->name); ?> ?')">
                                    <i class='bx bxs-trash'></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    </thead>
    </table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\module3\hoc-lai-m3\Project\resources\views/admin/products/recycleBin.blade.php ENDPATH**/ ?>