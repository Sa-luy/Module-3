;
<?php $__env->startSection('content'); ?>
    <div>
        <h3>Danh sách người dùng đã xóa</h3>
        <?php if(count($users) == 0): ?>
            <p>Danh sách trống</p>
        <?php else: ?>
    </div>
    <table class="table table-striped-columns">
        <thead>
            <tr>
                <td>#</td>
                <td>Tên</td>
                <td>Email</td>
                <td> Số Điện Thoại</td>
                <td> Thao tác</td>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($key); ?></a> </td>
                    <td> <?php echo e($user->name); ?></a></td>
                    <td> <?php echo e($user->email); ?></a></td>
                    <td><?php echo e($user->phone); ?></a></td>
                    <td>
                        <div class="row">
                            <div class="col-3">
                                <form action="<?php echo e(route('admin.user.restore', $user->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <button class="btn btn-danger align-middle" type="submit"
                                        onclick="return confirm('Bạn muốn khôi phục <?php echo e($user->name); ?> ?')">Restore</button>
                                </form>
                            </div>
                            <div class="col-3">
                                <form action="<?php echo e(route('user-force-delete', $user->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <button class="btn btn-danger align-middle" type="submit"
                                        onclick="return confirm('Bạn muốn xóa vĩnh viễn  <?php echo e($user->name); ?> ?')">
                                        Delete</button>
                                </form>
                            </div>

                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

    </table>
    <?php endif; ?>
    <?php echo e($users->links()); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\module3\hoc-lai-m3\Project\resources\views/admin/users/recycle.blade.php ENDPATH**/ ?>