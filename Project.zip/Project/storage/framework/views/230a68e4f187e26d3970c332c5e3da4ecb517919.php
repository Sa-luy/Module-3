;
<?php $__env->startSection('content'); ?>
    <style>
        .card-header {
            background-color: chartreuse
        }

        .card-body {
            color: blue;
        }
    </style>
    <div class="container">
        <div class="table-agile-info">
            <div class="panel panel-default">

                <div class="row w3-res-tb">
                    <div class="col-sm-5 m-b-xs">
                        <input type="text" class="input-sm form-control w-sm inline v-middle">
                        
                    </div>
                    <div class="col-sm-4">
                    </div>
                    <div class="col-sm-3">
                        <div class="input-group">
                            
                            <img src="<?php echo e(asset('images/hinh-anh-dong-hoat-hinh.gif')); ?>" alt="" width="100px">
                        </div>
                        <?php if(Session::has('messages')): ?>
                            <p class="text-success">
                                <i class="fa fa-check" aria-hidden="true"></i><?php echo e(Session::get('messages')); ?>

                            </p>
                        <?php endif; ?>

                    </div>
                </div>
                <div class="panel-heading">
                    <h3>Phân quyền</h3>
                </div>
                <div class="col-md-12">
                    <form action="<?php echo e(route('permissions.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        

                        
                        <div class="col-md-12">
                            

                            <div class="container">
                                <p>Thêm quyền cho trang wep</p>
                                <div class="card border-primary mb-3">
                                    <div class="card-header">
                                        <div class="row">
                                            <p>Cấp Quyền cho Module   <div class="col-12 form-check form-switch">
                                                <select class="form-select" aria-label="Default select example" name="module">
                                                    <option selected>Nhấp để chọn</option>
                                                    <?php $__currentLoopData = config('permissions.table'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($key); ?>"> <?php echo e($permission); ?></option>
                                                       
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </p>

                                        </div>
                                    </div>
                                    <div class="card-body text-primary">
                                    <p>Phân quyền
                                    <div class="col-12 form-check form-switch">
                                        <input class="form-check-input checkbox_wrapper" type="checkbox"
                                            role="switch"> Tất cả
                                        </div></p>
                                        <div class="row">
                                            <?php $__currentLoopData = config('permissions.action'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $permissionChild): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="col form-check form-switch ">
                                                    <input class="form-check-input checkbox_child" name="permission_ids[]"
                                                        type="checkbox" role="switch" value="<?php echo e($key); ?>">
                                                    <?php echo e($permissionChild); ?>

                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <input type="submit" class="btn btn-primary" value="ADD">
                    </form>
                </div>

            </div>

        </div>

    </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <script>
        $(".checkbox_wrapper").on('click', function() {
            $(this).parents('.card').find('.checkbox_child').prop('checked', $(this).prop('checked'));
        });
        $(".checkbox_all").on('click', function() {
            $(this).parents().find('.checkbox_child').prop('checked', $(this).prop('checked'));
            $(this).parents().find('.checkbox_wrapper').prop('checked', $(this).prop('checked'));
        });
    </script>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\module3\hoc-lai-m3\Project\resources\views/admin/permissions/add.blade.php ENDPATH**/ ?>