;
<?php $__env->startSection('content'); ?>
<h1>Order</h1>
<div class="row">
    <div class="col"><a href="<?php echo e(route('order.create')); ?>"><i class='bx bxs-comment-add btn btn-primary'></i></a></div>
    <div class="col">  <?php if(Session::has('messages')): ?>
        <p class="text-messages text-success">
            <i class="fa fa-check" aria-hidden="true"></i><?php echo e(Session::get('messages')); ?>

        </p>
    <?php endif; ?></div>
    <div class="col"><a href="<?php echo e(route('order-trashed')); ?>"><i class='bx bx-trash btn btn-danger' ></i></a></div>
</div>
  
    <?php if(count($orders) == 0): ?>
        <p>Empty Order</p>
        
    <?php else: ?>
   
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Name</th>
                        <th scope="col">Email address</th>
                        <th scope="col">Phone</th>
                        <th scope="col">Address</th>
                        <th scope="col">Order date</th>
                        <th scope="col">Notes</th>
                        
                        <th scope="col">Total Money</th>
                        <th scope="col">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><?php echo e($order->id); ?></td>
                        <td><?php echo e($order->fullname); ?></td>
                        <td><?php echo e($order->email); ?></td>
                        <td><?php echo e($order->phone); ?></td>
                        <td><?php echo e($order->address); ?></td>
                        <td><?php echo e($order->order_date); ?></td>
                        <td><?php echo e($order->notes); ?></td>
                        
                        <td><?php echo e($order->totalmoney); ?></td>
                        <td>
                            <label for="">
                                <a href="<?php echo e(route('order.show', $order->id)); ?>"><i class='bx bx-low-vision'></i></a>
                                <a href="<?php echo e(route('order.edit', $order->id)); ?>"><i class='bx bx-edit-alt'></i></a>
                                <a data-url="<?php echo e(route('order.destroy', $order->id)); ?>" class="deleteOrder"
                                    data-id="<?php echo e($order->id); ?>"><i class='bx bx-trash'></i></a>
                            </label>
                        </td>
                    </tr>
                </tbody>
            </table>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <script>
        $(function() {
            $('.deleteOrder').on('click', deleteOrder)
        })

        function deleteOrder(event) {
            event.preventDefault();
            let url = $(this).data('url');
            let id = $(this).data('id');
            Swal.fire({
                title: "Are you sure delete ?",
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    jQuery.ajax({
                        type: "delete",
                        'url': url,
                        'data': {
                            id: id,
                            _token: "<?php echo e(csrf_token()); ?>",
                        },
                        dataType: 'json',
                        success: function(data, ) {
                            if (data.status === 1) {
                                console.log(data);
                                window.location.reload();
                                alert(data.messages)

                            }
                            if (data.status === 0) {
                                console.log(data);
                                // window.location.reload();
                                alert(data.messages)

                            }
                        }
                    });

                }

            })
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\module3\hoc-lai-m3\Project\resources\views/admin/orders/index.blade.php ENDPATH**/ ?>