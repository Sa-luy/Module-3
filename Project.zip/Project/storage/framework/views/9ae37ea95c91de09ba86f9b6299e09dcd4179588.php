<div class="featured__item__pic set-bg"
                                data-setbg="<?php echo e(asset('storage/images/' . $product->image)); ?>">
                                <ul class="featured__item__pic__hover">
                                    <li><a href="#"><i class="bx bx-heart"></i></a></li>
                                    <li><a href="#"><i class='bx bx-message-rounded-edit'></i></a></li>
                                    <li><a href="#" data-url="<?php echo e(route('addToCart', $product->id)); ?>"
                                            class="addCart"><i class='bx bx-cart-alt'></i></a></li>
                                </ul>
                            </div>
<?php /**PATH C:\laragon\www\module3\hoc-lai-m3\Project\resources\views/fronten/custom/cart.blade.php ENDPATH**/ ?>