;
<?php $__env->startSection('content'); ?>
    <h3>Edit Oder</h3>
    <div class="col-10">
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Name</label>
            <input disabled type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"
                value="<?php echo e($order->fullname); ?>" name="fullname">

        </div>

        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Email address</label>
            <input disabled type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"
                value="<?php echo e($order->email); ?>" name="email">

        </div>

        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Phone</label>
            <input disabled type="number" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"
                value="<?php echo e($order->phone); ?>" name="phone">

        </div>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Address</label>
            <input disabled type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"
                value="<?php echo e($order->address); ?>" name="address">

        </div>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Notes</label>
            <input disabled type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"
                value="<?php echo e($order->notes); ?>" name="notes">

        </div>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Order date</label>
            <input disabled type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"
                value="<?php echo e($order->order_date); ?>" name="order_date">

        </div>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Status</label>
            <div class="form-floating">
                <select disabled class="form-select" id="floatingSelect" aria-label="Floating label select example"
                    name="status">
                    
                    <option <?php echo e($order->status == 'no' ? 'selected' : ''); ?> value="<?php echo e($order->status); ?>"><?php echo e($order->status); ?>

                    </option>
                    <option <?php echo e($order->status == 'no' ? 'selected' : ''); ?> value="<?php echo e($order->status); ?>"><?php echo e($order->status); ?>

                    </option>
                </select>

            </div>
            <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Total Money</label>
                <input disabled type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"
                    name="totalmoney" value="<?php echo e($order->totalmoney); ?>">


            </div>
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\module3\hoc-lai-m3\Project\resources\views/admin/orders/show.blade.php ENDPATH**/ ?>