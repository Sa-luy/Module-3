;
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="table-agile-info">
            <div class="panel panel-default">
                <div class="panel-heading">
                    thung rac 
                </div>
                <div class="row w3-res-tb">
                   
                    <div class="col-sm-4">
                    </div>
                    <div class="col-sm-3">
                        <div class="input-group">
                            
                            <span class="input-group-btn">
                                <a href="" class="btn btn-sm btn-default">Trash</a>
                            </span>
                        </div>
                        <?php if(Session::has('success')): ?>
                            <p class="text-success">
                                <i class="fa fa-check" aria-hidden="true"></i><?php echo e(Session::get('success')); ?>

                            </p>
                        <?php endif; ?>
                      
                    </div>
                </div>
                <div class="table-responsive">

                    <table class="table table-striped b-t b-light">
                        <thead>
                            <tr>
                                <th style="width:20px;">
                                    <label class="i-checks m-b-none">
                                        <input type="checkbox"><i></i>
                                    </label>
                                </th>
                                <th>#</th>
                                <th>Vai tro</th>
                                <th>Mô Tả</th>
                                <th>action</th>

                                <th style="width:30px;"></th>
                            </tr>
                        </thead>
                        <tbody>
                            
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo csrf_field(); ?>
                                    <tr>
                                        <td><label class="i-checks m-b-none"><input type="checkbox"
                                                    name="post[]"><i></i></label></td>
                                                    <td><?php echo e($role->id); ?></td>
                                        <td><?php echo e($role->name); ?></td>
                                        <td><?php echo e($role->display_name); ?> </td>
                                        <td>
                                            <form action="<?php echo e(route('admin.role.restore', $role->id)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <button class="btn btn-danger align-middle" type="submit"
                                                    onclick="return confirm('Bạn muốn Phục hồi <?php echo e($role->name); ?> ?')">Restore</button>
                                            </form>  
                                            <form action="<?php echo e(route('role-force-delete', $role->id)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <button class="btn btn-danger align-middle" type="submit"
                                                    onclick="return confirm('Bạn muốn xóa vĩnh viễn  <?php echo e($role->name); ?> ?')">Force
                                                    Delete</button>
                                            </form> 
                                        </td>  
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                                <tr>
                                    <td colspan="5">
                                        <p>Empty</p>
                                    </td>
                                </tr>
                            
                        </tbody>
                    </table>
                </div>
                <footer class="panel-footer">
                    <div class="row">

                        <div class="col-sm-5 text-center">
                            <small class="text-muted inline m-t-sm m-b-sm">showing 20-30 of 50 items</small>
                        </div>
                        <div class="col-sm-7 text-right text-center-xs">
                            <ul class="pagination pagination-sm m-t-none m-b-none">
                                
                            </ul>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\module3\hoc-lai-m3\Project\resources\views/admin/roles/recycle.blade.php ENDPATH**/ ?>