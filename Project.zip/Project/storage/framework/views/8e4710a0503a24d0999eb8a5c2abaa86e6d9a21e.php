;
<?php $__env->startSection('content'); ?>
 
<h1>Thêm  Danh Mục Sản Phẩm</h1>
<?php $__errorArgs = ['msg'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<div style="color: rgb(224, 18, 18)" class="alter alert-primary text-center"><?php echo e($message); ?></div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <form action="<?php echo e(route('category.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="row g-3 align-items-center">
            <div class="col-auto">
                <label for="inputPassword6" class="col-form-label">Tên Danh Mục</label>
            </div>
            <div class="col-auto">
                <input type="text" id="inputPassword6" class="form-control" aria-describedby="passwordHelpInline"
                    name="name" placeholder="nhập tên">
                    <?php if($errors->any()): ?>
                    <p style="color:red"><?php echo e($errors->first('name')); ?></p>
                <?php endif; ?>
            </div>
            <div class="col-auto">
                <span id="passwordHelpInline" class="form-text">
                    Vui Lòng nhập trên 8 kí tự.
                </span>
            </div>
        </div>
        <button type="submit" class="btn btn-info">Thêm</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\module3\hoc-lai-m3\Project\resources\views/admin/categories/add.blade.php ENDPATH**/ ?>