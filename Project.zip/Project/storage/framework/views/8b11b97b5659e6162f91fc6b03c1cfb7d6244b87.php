
<?php $__env->startSection('hot_product'); ?>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<div class="productsearch">
    <h1><b>Danh Sách tìm kiếm</b></h1>
    <div class="row">
    <?php $__currentLoopData = $search_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-lg-3 col-md-4 col-sm-6 mix oranges fresh-meat">
        <div class="featured__item">
            <div class="featured__item__pic set-bg"
                data-setbg="<?php echo e(asset('storage/images/' . $product->image)); ?>">
                <ul class="featured__item__pic__hover">
                    <li><a href="#"><i class="bx bx-heart"></i></a></li>
                    <li><a href="#"><i class='bx bx-message-rounded-edit'></i></a></li>
                    <li><a href="#"
                            data-url="
                        <?php if(Auth::guard('customer')->check()): ?> <?php echo e(route('addToCart', $product->id)); ?> <?php endif; ?>
                        "
                            class="addCart"><i class='bx bx-cart-alt'></i></a></li>
                </ul>
                
            </div>
            <div class="featured__item__text">
                <h6><a href="#"><?php echo e($product->name); ?></a></h6>
                <h5><?php echo e(number_format($product->price)); ?></h5>
                <h6><?php echo e($product->description); ?></h6>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>

<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    $(function() {
        $('.addCart').on('click', addToCart)
    })

    function addToCart(event) {
        event.preventDefault();
        let url = $(this).data('url');

        $.ajax({
            type: "GET",
            url: url,
            dataType: 'json',
            success: function(data) {
                Swal.fire({
                    position: 'top-end',
                    icon: 'success',
                    title: 'successfully added to cart',
                    showConfirmButton: false,
                    timer: 1500
                })
                window.location.reload();
            },
            error: function(data) {
                Swal.fire({
  icon: 'error',
  title: 'Oops...',
  text: 'Something went wrong!',
  footer: '<a href="">Why do I have this issue?</a>'
})
            }

        });
    }
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('fronten.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\module3\hoc-lai-m3\Project\resources\views/fronten/custom/search.blade.php ENDPATH**/ ?>