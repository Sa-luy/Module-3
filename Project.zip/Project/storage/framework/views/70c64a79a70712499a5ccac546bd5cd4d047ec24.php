<?php $__env->startSection('content'); ?>

<h5>Hello <?php echo e(Auth::user()->name); ?></h5>
<div class="row dash-row">
    <div class="col-xl-4">
        <div class="stats stats-primary">
            <h3 class="stats-title"><?php echo e(__('lang.routename.product')); ?> </h3>
            <div class="stats-content">
                <div class="stats-icon">
                    <i class='bx bx-category'></i>
                </div>
                <div class="stats-data">
                    <div class="stats-number"><?php echo e(count($products_home)); ?></div>
                    <div class="stats-change">
                        <span class="stats-percentage">+25%</span>
                        <span class="stats-timeframe">from last month</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xl-4">
        <div class="stats stats-success ">
            <h3 class="stats-title"> <?php echo e(__('lang.routename.category')); ?>  </h3>
            <div class="stats-content">
                <div class="stats-icon">
                    <i class="fas fa-cart-arrow-down"></i>
                </div>
                <div class="stats-data">
                    <div class="stats-number"><?php echo e(count($categories_home)); ?></div>
                    <div class="stats-change">
                        <span class="stats-percentage">+17.5%</span>
                        <span class="stats-timeframe">from last month</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xl-4">
        <div class="stats stats-danger">
            <h3 class="stats-title">Total Money</h3>
            <div class="stats-content">
                <div class="stats-icon">
                    <i class="fas fa-phone"></i>
                </div>
                <div class="stats-data">
                    <div class="stats-number">5</div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\module3\hoc-lai-m3\Project\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>