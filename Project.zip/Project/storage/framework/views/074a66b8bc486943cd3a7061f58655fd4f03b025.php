;
<?php $__env->startSection('content'); ?>
    <div class="customers">
        <table class="table table-striped">
            <thead>
                <th>#</th>
                <th>Name</th>
                <th>Phone</th>
                <th>Adress</th>
                <th>Email</th>
                <th>Provider</th>
                <th>Log out date</th>
                <th>Action</th>
            </thead>
            <tbody>
                    <tr>
                        <td><?php echo e($customer->id); ?></td>
                        <td><?php echo e($customer->name); ?></td>
                        <td><?php echo e($customer->phone); ?></td>
                        <td><?php echo e($customer->address); ?></td>
                        <td><?php echo e($customer->email); ?></td>
                        <td><?php echo e($customer->provider_name); ?></td>
                        <td><?php echo e($customer->updated_at); ?></td>
                        <td>
                             
                  <a data-url="<?php echo e(route('customer.destroy', $customer->id)); ?>" id="<?php echo e($customer->id); ?>"
                        class="sm deleteCustomer"><i class=" fas fa-trash-alt "></i>
                    </a> 
                


                            <td>
                                <a href="">3</a>
                            </td>

                            </td>
                        </tr>
                </tbody>
            </table>
        </div>
    <?php $__env->stopSection(); ?>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
  
    $(function() {
        $('.deleteCustomer').on('click', deleteCustomer)
    })

    function deleteCustomer(event) {
        event.preventDefault();
        let url = $(this).data('url');
        let id = $(this).data('id');
        Swal.fire({
            title: "Are you sure delete <?php echo e($customer->name); ?>?",
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
            if (result.isConfirmed) {
                jQuery.ajax({
                    type: "delete",
                    'url': url,
                    'data': {
                        id: id,
                        _token: "<?php echo e(csrf_token()); ?>",
                    },
                    dataType: 'json',
                    success: function(data, ) {
                        if (data.status === 1) {
                            window.location="<?php echo e(route('customer.index')); ?>";
                            alert(data.messages)

                        } 
                        if (data.status === 0) {
                            window.location="<?php echo e(route('customer.index')); ?>";
                            alert(data.messages)

                        } 
                        }
                });

            }

        })
    }
</script>

<?php echo $__env->make('admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\module3\hoc-lai-m3\Project\resources\views/admin/customers/show.blade.php ENDPATH**/ ?>