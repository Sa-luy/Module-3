
<?php $__env->startSection('hot_product'); ?>
<div class="container">
    <div class="" style="margin-bottom: 50px; margin-top: 20px">Search advance</div>
    <div class="row" id="search" >
        <form id="search-form" action="<?php echo e(route('search_advance_product')); ?>" method="POST" >
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <div>Name:</div>
                 <input class="form-control" type="text" name="name" placeholder="name" />
            </div>

            <div class="form-group">
                <div>Status:</div>
                
                    <input type="text" class="form-control">
                </select>
            </div>
            <div class="form-group">
                <div>Description</div>
                <input class="form-control" type="text" name="description" placeholder="description" />

            </div>

            <div class="form-group">
                <div>Price:</div>
                <input class="form-control" type="text" name="price" placeholder="price" />
            </div>

            <div class="form-group col-xs-3">
                <button type="button" class="btn btn-block btn-primary" id="search-product" onclick="search()">Search</button>
            </div>
        </form>
    </div>
    <div class="row" id="products">

    </div>
</div>

<script>
        function search() {
                $.ajax({
                    type: "POST",
                    url: '<?php echo e(route('search_advance_product')); ?>',
                    data: $("#search-form").serialize(),
                    success: function(data)
                    {
                        $('#products').html(data);
                    }
                });
        }
</script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('fronten.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\module3\hoc-lai-m3\Project\resources\views/fronten/custom/search-advance.blade.php ENDPATH**/ ?>