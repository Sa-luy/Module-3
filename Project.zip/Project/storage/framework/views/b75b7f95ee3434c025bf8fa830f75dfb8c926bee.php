;
<?php $__env->startSection('content'); ?>
    <div>
        <h3>Danh Sách Người dùng</h3>
        <table class="table table-striped-columns">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Tên</th>
                    <th>Email</th>
                    <th> Số Điện Thoại</th>
                    <th> Địa chỉ</th>
                    <th> Ngày tháng năm sinh</th>
                    <th> Ảnh</th>

                    <th> Thao tác</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><?php echo e($user->id); ?> </td>
                    <td> <?php echo e($user->name); ?></td>
                    <td> <?php echo e($user->email); ?></td>
                    <td><?php echo e($user->phone); ?></td>
                    <td><?php echo e($user->address); ?></td>
                    <td><?php echo e($user->day_of_birth); ?></td>
                    <td>
                        <img src="<?php echo e(asset('storage/images/user/' . $user->image)); ?>" alt="" style="height: 100px">
                    </td>
                    <td>
                        <a href="<?php echo e(route('user.edit', $user->id)); ?>">Edit</a>
                        <form action=""<?php echo method_field('POST'); ?>>1
                            <input type="submit" value="DElete">
                        </form>
                    </td>
                </tr>
            </tbody>

        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\module3\hoc-lai-m3\Project\resources\views/admin/users/show.blade.php ENDPATH**/ ?>