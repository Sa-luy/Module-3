;
<?php $__env->startSection('content'); ?>
    <br>
    <br>
    <form action="<?php echo e(route('category.update', $category->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="row g-3 align-items-center">
            <div class="col-auto">
                <label for="inputPassword6" class="col-form-label">Sửa Tên Danh Mục</label>
            </div>
            <div class="">
                <input type="text" id="" class="form-control" aria-describedby="passwordHelpInline"
                    name="name" value="<?php echo e($category->name); ?>">
                    <?php if($errors->any()): ?>
                    <p style="color: rgb(181, 33, 33)"><?php echo e($errors->first('name')); ?></p>
                    <?php endif; ?>
            </div>
            <div class="col-auto">
                <span id="passwordHelpInline" class="form-text">
                    Vui Lòng nhập trên 8 kí tự.
                </span>
            </div>
        </div>
        <button type="submit" class="btn btn-info">Lưu lại</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\module3\hoc-lai-m3\Project\resources\views/admin/categories/edit.blade.php ENDPATH**/ ?>