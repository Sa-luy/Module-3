;
<?php $__env->startSection('content'); ?>
    <div class="row">

        <div class="col"></div>

        <div class="col">
            <?php if(Session::has('fail')): ?>
                <p class="text-danger"><?php echo e(Session::get('fail')); ?></p>
            <?php endif; ?>
            
        </div>

        <div class="col"></div>

    </div>

    <div class="customer col-6">
        <form action="<?php echo e(route('customer.update',$customer->id)); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <?php echo method_field('PUT'); ?>
            <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Name</label>
                <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"
                    name="name" value="<?php echo e($customer->name); ?>">
            </div>

            <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Phone</label>
                <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"
                    name="phone" value="<?php echo e($customer->phone); ?>">
            </div>

            <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Email address</label>
                <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"
                    name="email" value="<?php echo e($customer->email); ?>">
            </div>

            <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Address</label>
                <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"
                    name="address" value="<?php echo e($customer->address); ?>">
            </div>

            <div class="mb-3">
                <label for="exampleInputPassword1" class="form-label">Register Date</label>
                <input type="text" class="form-control" id="exampleInputPassword1" name="created_at"
                    value="<?php echo e($customer->created_at); ?>">
            </div>

            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\module3\hoc-lai-m3\Project\resources\views/admin/customers/edit.blade.php ENDPATH**/ ?>