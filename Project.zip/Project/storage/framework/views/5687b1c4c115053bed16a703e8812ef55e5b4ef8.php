;
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="table-agile-info">
            <div class="panel panel-default">
                <div class="panel-heading">
                </div>
                <div class="row w3-res-tb">
                    <h3>Danh Sách Vai Trò</h3>
                    <div class="row">
                        <div class="col-4">
                            <a href="<?php echo e(route('role.create')); ?>" class="btn btn-sm btn-success">
                                <button type="subit" class="btn btn-labeled">

                                    <i class='bx bx-message-add'></i>

                                </button>
                            </a>
                            
                        </div>
                        <div class="col-4">
                            <?php if(Session::has('success')): ?>
                                <p class="text-success">
                                    <i class="fa fa-check" aria-hidden="true"></i><?php echo e(Session::get('success')); ?>

                                </p>
                            <?php endif; ?>
                        </div>
                        <div class="col-4">

                            <a href="<?php echo e(route('role-trashed')); ?>" class="btn btn-sm btn-danger"><button type="subit"
                                    class="btn btn-labeled">
                                    <i class="fa fa-trash"></i></button></a>
                        </div>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-striped b-t b-light">
                            <thead>
                                <tr>
                                    <th style="width:20px;">
                                        <label class="i-checks m-b-none">
                                            <input type="checkbox"><i></i>
                                        </label>
                                    </th>
                                    <th>#</th>
                                    <th>Vai tro</th>
                                    <th>Mô Tả</th>
                                    <th>action</th>
                                    <th style="width:30px;"></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo csrf_field(); ?>
                                    <tr>
                                        <td><label class="i-checks m-b-none"><input type="checkbox"
                                                    name="post[]"><i></i></label></td>
                                        <td><?php echo e($role->id); ?></td>
                                        <td><?php echo e($role->name); ?></td>
                                        <td><?php echo e($role->display_name); ?>

                                        <td>
                                       
                                            <a href="<?php echo e(route('role.edit', $role->id)); ?>" class="btn btn-info sm">
                                                <i class="fas fa-edit "></i>
                                            </a>
                                            
                                            
                                            <a data-href="" data-id="<?php echo e($role->id); ?>"
                                                data-url="<?php echo e(route('role.destroy', $role->id)); ?>"
                                                class="btn btn-danger sm deleteIcon"><i class=" fas fa-trash-alt "></i>
                                            </a>
                                            
                                            
                                            <a href="<?php echo e(route('role.show', $role->id)); ?>"
                                                class="btn btn-primary waves-effect waves-light">
                                                <i class="fa-solid fa-eye"></i>
                                            </a>
                                            
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <footer class="panel-footer">
                        <div class="row">
                            <div class="col-sm-5 text-center">
                                <small class="text-muted inline m-t-sm m-b-sm">showing 1-5 of <?php echo e(count($roles)); ?>

                                    items</small>
                            </div>
                            <div class="col-sm-7 text-right text-center-xs">
                                <ul class="pagination pagination-sm m-t-none m-b-none">

                                </ul>
                            </div>
                        </div>
                    </footer>
                </div>
            </div>
        </div>
        <script>
      
            $(function() {
                $('.deleteIcon').on('click', deleteRole)
            })

            function deleteRole(event) {
                event.preventDefault();
                let url = $(this).data('url');
                let id = $(this).data('id');
                Swal.fire({
                    title: "Are you sure delete<?php echo e($role->name); ?>?",
                    text: "You won't be able to revert this!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        jQuery.ajax({
                            type: "delete",
                            'url': url,
                            'data': {
                                id: id,
                                _token: "<?php echo e(csrf_token()); ?>",
                            },
                            dataType: 'json',
                            success: function(data, ) {
                                if (data.status === 1) {
                                    // window.location.reload();
                                    // alert(data.messages)

                                }
                            },
                            error: function(data) {
                                if (data.status === 0) {
                                    alert(data.messages)
                                }
                            }
                        });

                    }

                })
            }
        </script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\module3\hoc-lai-m3\Project\resources\views/admin/roles/index.blade.php ENDPATH**/ ?>