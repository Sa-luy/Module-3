;
<?php $__env->startSection('content'); ?>
    <div class="product">
        <div class="mb-3">
            <b for="exampleInputEmail1" class="form-label"><?php echo e(__('lang.name-product')); ?></b>
            <p class="text-info"><?php echo e($product->name); ?></p>
            <hr>
        </div>
        <div class="mb-3">
            <b for="exampleInputEmail1" class="form-label"><?php echo e(__('lang.category-name')); ?></b>
           <p><a href="<?php echo e(route('category.show',$product->category->id)); ?>"
            style="text-decoration: none"><?php echo e($product->category->name); ?></a></p> 
            <hr>
        </div>
        <div class="mb-3">
            <b for="exampleInputEmail1" class="form-label "><?php echo e(__('lang.quantity')); ?></b>
            <p class="text-info"><?php echo e($product->amouth); ?></p>
            <hr>
        </div>
        <div class="mb-3">
            <b for="exampleInputEmail1" class="form-label"><?php echo e(__('lang.description')); ?></b>
            <p class="text-info"><?php echo e($product->description); ?></p>
            <hr>
        </div>
        <div class="mb-3">
            <b for="exampleInputEmail1" class="form-label"><?php echo e(__('lang.use')); ?></b>
            <p class="text-info"><?php echo e($product->use); ?></p>
            <hr>
        </div>
        <div class="mb-3">
            <b for="exampleInputEmail1" class="form-label"><?php echo e(__('lang.appendix')); ?></b>
            <p class="text-info"><?php echo e($product->status); ?></p>
            <hr>
        </div>
        <div class="mb-3">
            <b for="exampleInputEmail1" class="form-label"><?php echo e(__('lang.image')); ?></b>
            <p><img src="<?php echo e(asset('storage/images/' . $product->image)); ?>" alt=""></p>
            <hr>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\module3\hoc-lai-m3\Project\resources\views/admin/products/show.blade.php ENDPATH**/ ?>