;
<?php $__env->startSection('content'); ?>
    <div>
        <h3>Sửa thông tin Người dùng</h3>
        <?php $__errorArgs = ['msg'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <h3 style="color: rgb(232, 13, 16); height:40px;" class="alter alert-primary text-center"><?php echo e($message); ?></h3>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <form action="<?php echo e(route('user.update', $user->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Tên</label>
                <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="name"
                    value="<?php echo e($user->name); ?>">
                    <?php if($errors->any()): ?>
                    <p style="color:red"><?php echo e($errors->first('name')); ?></p>
                <?php endif; ?>
            </div>

            <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Email</label>
                <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"
                    name="email" value="<?php echo e($user->email); ?>">
                    <?php if($errors->any()): ?>
                    <p style="color:red"><?php echo e($errors->first('email')); ?></p>
                <?php endif; ?>
            </div>

            <div class="mb-3">
                <label for="exampleInputPassword1" class="form-label">Phone</label>
                <input type="number" class="form-control" id="exampleInputPassword1" name="phone"
                    value="<?php echo e($user->phone); ?>">
                    <?php if($errors->any()): ?>
                    <p style="color:red"><?php echo e($errors->first('phone')); ?></p>
                <?php endif; ?>
            </div>

            <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Dia chi</label>
                <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"
                    name="address" value="<?php echo e($user->address); ?>">
                    <?php if($errors->any()): ?>
                    <p style="color:red"><?php echo e($errors->first('phone')); ?></p>
                <?php endif; ?>
            </div>
            
            <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Ngay Sinh</label>
                <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"
                    name="day_of_birth" value="<?php echo e($user->day_of_birth); ?>">
                    <?php if($errors->any()): ?>
                    <p style="color:red"><?php echo e($errors->first('phone')); ?></p>
                <?php endif; ?>
            </div>

            <div class="mb-3">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.label','data' => ['for' => 'role_id','value' => __('Chon Vai tro')]] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'role_id','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Chon Vai tro'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                <select class="js-example-basic-multiple form-control" name="role_id[]"  multiple="multiple">
                 
                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($role->id); ?>" 
                            <?php $__currentLoopData = $user_role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($item== $role->id): ?>
                                <?php echo e('selected'); ?>

                                    
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            ><?php echo e($role->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if($errors->any()): ?>
                <p style="color:red"> <?php echo e($errors->first('role_id')); ?></p>
             <?php endif; ?>
            </div>

            <div class="mb-3">
                <label for="exampleInputEmail1" class="form-label">Ảnh</label>
                <input type="file" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"
                    name="image" value="<?php echo e(asset('storage/images/user/'. $user->image )); ?>">
                    <img src="<?php echo e(asset('storage/images/user/'. $user->image )); ?>" alt=""
                            style="height: 100px">
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    

    </div>
   
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\module3\hoc-lai-m3\Project\resources\views/admin/users/edit.blade.php ENDPATH**/ ?>