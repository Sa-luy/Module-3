;
<?php $__env->startSection('content'); ?>
    <style>
        .card-header {
            background-color: chartreuse
        }

        .card-body {
            color: blue;
        }
    </style>
    <div class="container">
        <div class="table-agile-info">
            <div class="panel panel-default">

                <div class="row w3-res-tb">
                    <div class="col-sm-5 m-b-xs">
                        <input type="text" class="input-sm form-control w-sm inline v-middle">
                        
                    </div>
                    <div class="col-sm-4">
                    </div>
                    <div class="col-sm-3">
                        <div class="input-group">
                            
                            <img src="<?php echo e(asset('images/hinh-anh-dong-hoat-hinh.gif')); ?>" alt="" width="100px">
                        </div>
                        <?php if(Session::has('messages')): ?>
                            <p class="text-success">
                                <i class="fa fa-check" aria-hidden="true"></i><?php echo e(Session::get('messages')); ?>

                            </p>
                        <?php endif; ?>

                    </div>
                </div>
                <div class="panel-heading">
                    <h3>Thêm Role</h3>
                </div>
                <div class="col-md-12">
                    <form action="<?php echo e(route('role.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <p>Định danh Vai trò :</p>
                        <input type="text" name="name" class="input-sm form-control"value="<?php echo e(old('name')); ?>">
                        <p>Mô Tả Vai trò:</p>
                        <textarea name="display_name" id="" cols="100" rows="5" class="input-sm form-control" value="<?php echo e(old('display_name')); ?>"></textarea>

                        
                        <div class="col-md-12">
                            <div class="col-12 form-check form-switch">
                                <label >
                                    <input class="form-check-input checkbox_all" type="checkbox"
                                    role="switch">
                                    Check All</label>
                            </div>

                            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="container">
                                    <div class="card border-primary mb-3">
                                        <div class="card-header">
                                            <div class="row">
                                                <div class="col-12 form-check form-switch">
                                                    <input class="form-check-input checkbox_wrapper" type="checkbox"
                                                        role="switch">

                                                    <?php echo e($permission->name); ?>

                                                </div>

                                            </div>
                                        </div>
                                        <div class="card-body text-primary">
                                            <div class="row">
                                                <?php $__currentLoopData = $permissionsChilds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permissionChild): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="col form-check form-switch ">
                                                        <input class="form-check-input checkbox_child"
                                                            name="permission_ids[]" type="checkbox" role="switch"
                                                            value="<?php echo e($permissionChild->id); ?>">
                                                        <?php echo e($permissionChild->name); ?>

                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <input type="submit" class="btn btn-primary" value="ADD">
                    </form>
                </div>

            </div>

        </div>

    </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <script>
        $(".checkbox_wrapper").on('click', function() {
            $(this).parents('.card').find('.checkbox_child').prop('checked', $(this).prop('checked'));
        });
        $(".checkbox_all").on('click', function() {
            $(this).parents().find('.checkbox_child').prop('checked', $(this).prop('checked'));
            $(this).parents().find('.checkbox_wrapper').prop('checked', $(this).prop('checked'));
        });
    </script>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\module3\hoc-lai-m3\Project\resources\views/admin/roles/add.blade.php ENDPATH**/ ?>