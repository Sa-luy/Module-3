
<?php $__env->startSection('hot_product'); ?>
    <?php if(!empty($search_products)): ?>
        <table class="table table-striped table-hover">
            <thead>
                <tr>
                    <th scope="col">Mã Sản phẩm</th>
                    <th scope="col">Tên</th>
                    <th scope="col">Giá</th>
                    <th scope="col">Mô tả</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $search_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($item->id); ?></th>
                            <td><a href="<?php echo e(route('guest.product_show', $item->id)); ?>"><?php echo e($item->name); ?></a></td>
                            <td><?php echo e($item->price); ?></td>
                            <td><?php echo e($item->name); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <p>Trống</p>
    <?php endif; ?>



<?php $__env->stopSection(); ?>






<?php echo $__env->make('fronten.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\module3\hoc-lai-m3\Project\resources\views/fronten/custom/search_advance.blade.php ENDPATH**/ ?>