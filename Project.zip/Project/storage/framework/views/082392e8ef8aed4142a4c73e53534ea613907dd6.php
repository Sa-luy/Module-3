;
<?php $__env->startSection('content'); ?>

    <br>
    <h2><?php echo e(__('lang.product-list')); ?></h2>
    <div class="row">

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', \App\Models\Product::class)): ?>
            <div class="col">
                <a href="<?php echo e(route('product.create')); ?>" class="btn btn-primary "><i class="fa-solid fa-calendar-plus"></i></a>
              
            </div>
        <?php endif; ?>
        <div class="col">
            <?php if(Session::has('success')): ?>
                <p class="text-success">
                    <i class="fa fa-check" aria-hidden="true"></i><?php echo e(Session::get('success')); ?>

                </p>
            <?php endif; ?>
        </div>

        <div class="col">
            <div class="input-group">
                
                <span class="input-group-btn">
                    <h2> <a href="<?php echo e(route('product-trashed')); ?>" class="btn btn-sm ">
                        <button type="subit" class="btn btn-labeled btn-danger">
                            <span class="btn-label"><i class="fa fa-trash"></i>Trash</span></button></a>
                </span>
            </div>
        </div>
    </div>
    <?php if(count($products) == 0): ?>
        <p><?php echo e(__('lang.empty-list')); ?></p>
    <?php else: ?>
        <table class="table table-striped">
            
            <thead>
                <tr>
                    <th>#</th>
                    <th><?php echo e(__('lang.name-product')); ?></th>
                    <th><?php echo e(__('lang.price')); ?></th>
                    <th><?php echo e(__('lang.quantity')); ?></th>
                    <th><?php echo e(__('lang.category-name')); ?></th>
                    <th><?php echo e(__('lang.image-list')); ?></th>
                    <th><?php echo e(__('lang.action')); ?></th>
                </tr>

                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="text-center"><?php echo e($product->id); ?></td>
                        <td><?php echo e($product->name); ?></td>
                        <td><?php echo e($product->price); ?></td>
                        <td><?php echo e($product->amouth); ?></td>
                        <td><?php echo e($product->category->name ?? 'chưa nhập danh mục'); ?></td>
                        <td>
                            <img src="<?php echo e(asset('storage/images/' . $product->image)); ?>" alt=""
                                style="width: 100px">
                        </td>
                        <td>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', \App\Models\Product::class)): ?>
                                <a href="<?php echo e(route('product.edit', $product->id)); ?>" class="">
                                    <i class="fa-solid fa-pen-to-square"></i>
                                </a>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', \App\Models\Product::class)): ?>
                                <a data-url="<?php echo e(route('product.destroy', $product->id)); ?>" id="<?php echo e($product->id); ?>"
                                    class="sm deleteProduct"><i class=" fas fa-trash-alt "></i>
                                </a>
                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view', \App\Models\Product::class)): ?>
                                <a href="<?php echo e(route('product.show', $product->id)); ?>" class="waves-effect waves-light">
                                    <i class="fa-solid fa-eye"></i>
                                </a>
                            <?php endif; ?>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </thead>
        </table>
        <?php endif; ?>
    <?php echo e($products->links()); ?>

    <footer class="panel-footer">
        <div class="row">
            <div class="col-sm-12 text-center">
                <small
                    class="text-muted inline m-t-sm m-b-sm"><?php echo e(__('lang.showing-1-5-of ') . $sum_product . __(' lang.items-product')); ?></small>
            </div>
            <div class="col-sm-7 text-right text-center-xs">
                <ul class="pagination pagination-sm m-t-none m-b-none">

                </ul>
            </div>
        </div>
    </footer>
    <script>
        $(function() {
            $('.deleteProduct').on('click', deleteProduct)
        })

        function deleteProduct(event) {
            event.preventDefault();
            let url = $(this).data('url');
            let id = $(this).data('id');
            Swal.fire({
                title: "Are you sure delete <?php echo e($product->name); ?>?",
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    jQuery.ajax({
                        type: "delete",
                        'url': url,
                        'data': {
                            id: id,
                            _token: "<?php echo e(csrf_token()); ?>",
                        },
                        dataType: 'json',
                        success: function(data, ) {
                            if (data.status === 1) {
                                console.log(data);
                                window.location.reload();
                                alert(data.messages)

                            }
                            if (data.status === 0) {
                                console.log(data);
                                // window.location.reload();
                                alert(data.messages)

                            }
                        }
                    });

                }

            })
        }
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\module3\hoc-lai-m3\Project\resources\views/admin/products/index.blade.php ENDPATH**/ ?>