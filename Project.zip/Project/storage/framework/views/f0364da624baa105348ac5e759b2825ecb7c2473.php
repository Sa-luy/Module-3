;
<?php $__env->startSection('content'); ?>
    <h1>
        List Product</h1>
    <div class="row">
        <div class="col">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create', \App\Models\Category::class)): ?>

            <a href="<?php echo e(route('category.create')); ?>" class="btn btn-primary ">Add</a>
            <?php endif; ?>
        </div>
        <div class="col">
            <?php if(Session::has('success')): ?>
                <p class="text-success">
                    <i class="fa fa-check" aria-hidden="true"></i><?php echo e(Session::get('success')); ?>

                </p>
            <?php endif; ?>
        </div>
        <div class="col">
            <?php if(Session::has('erors')): ?>
                <p class="text-success">
                    <i class="fa fa-check" aria-hidden="true"></i><?php echo e(Session::get('erors')); ?>

                </p>
            <?php endif; ?>
        </div>
        <div class="col input-group">
            <span class="input-group-btn">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', \App\Models\Category::class)): ?>
                <a href="<?php echo e(route('category-trashed')); ?>" class="btn btn-sm btn-danger">
                    <button type="subit" class="btn btn-labeled btn-danger">
                        <span class="btn-label"><i class="fa fa-trash"></i>Trash</span></button></a>
                        <?php endif; ?>
            </span>
        </div>
    </div>
    <table class="table table-striped table-hover align-middle">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Name</th>
                <th scope="col">Quantity</th>
                <th scope="col" class="text-center">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="item-<?php echo e($category->id); ?>">
                    <th><?php echo e($key+1); ?></th>
                    <td class="text-center"><?php echo e($category->name); ?></td>
                    
                    <td class="text-center"><?php echo e($category->products->count()); ?></td>
                    <td>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', \App\Models\Category::class)): ?>

                        <a href="<?php echo e(route('category.edit', $category->id)); ?>" class="btn btn-info sm">
                            <i class="fas fa-edit "></i>
                        </a>

                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', \App\Models\Category::class)): ?>
                        <a data-url="<?php echo e(route('category.destroy', $category->id)); ?>"data-id="<?php echo e($category->id); ?>"
                            class="btn btn-danger sm deleteCategory"><i class=" fas fa-trash-alt "></i>
                        </a>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view', \App\Models\Category::class)): ?>
                        
                        <a href="<?php echo e(route('category.show', $category->id)); ?>"
                            class="btn btn-primary waves-effect waves-light">
                            <i class="fa-solid fa-eye"></i>
                        </a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

    </table>
    <?php echo e($categories->links()); ?>

    <footer class="panel-footer">
        <div class="row">
            <div class="col-sm-12 text-center">
                <small class="text-muted inline m-t-sm m-b-sm"><?php echo e(__('lang.showing-1-5-of').$sum_category .__('lang.items-category')); ?></small>
            </div>
            <div class="col-sm-7 text-right text-center-xs">
                <ul class="pagination pagination-sm m-t-none m-b-none">
                </ul>
            </div>
        </div>
    </footer>

    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
      
        $(function() {
            $('.deleteCategory').on('click', deleteCategory)
        })

        function deleteCategory(event) {
            event.preventDefault();
            let url = $(this).data('url');
            let id = $(this).data('id');
            Swal.fire({
                title: "Are you sure delete ?",
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    jQuery.ajax({
                        type: "delete",
                        'url': url,
                        'data': {
                            id: id,
                            _token: "<?php echo e(csrf_token()); ?>",
                        },
                        dataType: 'json',
                        success: function(data, ) {
                            if (data.status === 1) {
                                console.log(data);
                                window.location.reload();
                                alert(data.messages)

                            } 
                            if (data.status === 0) {
                                console.log(data);
                                window.location.reload();
                                alert(data.messages)

                            } 
                            }
                    });

                }

            })
        }
    </script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.3/font/bootstrap-icons.css">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\module3\hoc-lai-m3\Project\resources\views/admin/categories/index.blade.php ENDPATH**/ ?>