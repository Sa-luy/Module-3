;
<?php $__env->startSection('content'); ?>
    <div class="category">
        <center><div class="mb-3">
            <b for="category" class="form-label">Tên Danh Mục :</b>
            <h5 class="text-success"><?php echo e($category->name); ?></h5>
        </div></center>
        
        <div class="mb-3">

            <b for="category" class="form-label">Sản phẩm trong danh mục :</b>
            <?php $__currentLoopData = $products_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <p> <a href="<?php echo e(route('product.show', $product_category->id)); ?>"
            style="text-decoration: none"
                class="text-center"><?php echo e($product_category->name); ?></a></p> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\module3\hoc-lai-m3\Project\resources\views/admin/categories/show.blade.php ENDPATH**/ ?>