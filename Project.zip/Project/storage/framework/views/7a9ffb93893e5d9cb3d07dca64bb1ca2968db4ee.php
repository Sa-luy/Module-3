<div class="cart">
    <h1>Giỏ Hàng</h1>
    <?php if(empty($carts)): ?>
        <p>chưa có sản phẩm nào</p>
        <a href="<?php echo e(route('home')); ?>">tiếp tục mua sắm</a>
    <?php else: ?>
        <table class="table updateCartUrl" data-url="<?php echo e(route('updateToCart')); ?>">
            <thead>
                <tr>
                    <th scope="col">Ma San Pham</th>
                    <th scope="col">Anh</th>
                    <th scope="col">Tên Sản phẩm</th>
                    <th scope="col">Giá</th>
                    <th scope="col">Số lượng</th>
                    <th scope="col">Tạm tính</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>


                <form action="<?php echo e(route('customerOrder')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php
                        $total = 0;
                        $totalAll = 0;
                    ?>
                    <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $total = $item['price'] * $item['quantity'];
                            $totalAll += $total;
                            // dd($total)
                        ?>
                        <tr>
                            <th scope="row">
                                <input class="product_id" type="hidden" value="<?php echo e($item['product_id']); ?>"
                                name="product_id[]">
                                <?php echo e($item['product_id']); ?>

                            </th>
                            <td>
                                <div class="featured__item__pic set-bg" style="width: 200;"
                                    data-setbg="<?php echo e(asset('storage/images/' . $item['image'])); ?>">
                            </td>
                            <td>
                                <input class="name" type="hidden" value="<?php echo e($item['name']); ?>"
                                    name="name[]"><?php echo e($item['name']); ?>

                            </td>
                            <td>
                                <input class="price" type="hidden" value="<?php echo e($item['price']); ?>"
                                    name="price[]"><?php echo e($item['price']); ?>

                            </td>
                            <td>
                                <input class="quantity" type="number" value="<?php echo e($item['quantity']); ?>"
                                    name="quantity[]">
                            </td>
                            <td>
                                <input class="name" type="hidden" value="<?php echo e($total); ?>"
                                    name="total"><?php echo e($total); ?>

                                    <input class="name" type="hidden" value="<?php echo e($totalAll); ?>"
                                    name="totalAll">

                            </td>

                            <td>
                                <a data-url="<?php echo e(route('updateToCart')); ?>"data-id="<?php echo e($item['product_id']); ?>"
                                    class="btn btn-primary cart_update">
                                    cập nhật
                                </a>
                                <a href="" data-id="<?php echo e($item['product_id']); ?>" class="btn btn-danger cart_delete"
                                    data-url="<?php echo e(route('deleteToCart')); ?>">
                                    xóa
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
            </tbody>
        </table>

        <h5>Form Checkout</h5>
        <div class="mb-3">
            <label for="exampleInputPassword1" class="form-label">
                Name
            </label>
            <input type="text" class="form-control" id="exampleInputPassword1" name="fullname"
                value="<?php echo e(Auth::guard('customer')->user()->name); ?>">
        </div>

        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">
                Email address
            </label>
            <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"
                name="email" value="<?php echo e(Auth::guard('customer')->user()->email); ?>">
        </div>
         
        <div class="mb-3">
            <label for="exampleInputPassword1" class="form-label">
                Address
            </label>
            <input type="text" class="form-control" id="exampleInputPassword1" name="address"
                value="<?php echo e(Auth::guard('customer')->user()->address); ?>">
        </div>

        <div class="mb-3">
            <label for="exampleInputPassword1" class="form-label">
                Phone
            </label>
            <input type="number" class="form-control" id="exampleInputPassword1" name="phone"
                value="<?php echo e(Auth::guard('customer')->user()->phone); ?>">
        </div>

        <div class="mb-3">
            <label for="exampleInputPassword1" class="form-label">
                Total Money
            </label>
            <input  disabled type="text" class="form-control" id="exampleInputPassword1" name="totalmoney" 
            value="<?php echo e(number_format($totalAll)); ?>">
        </div>
        <button type="submit" class="btn btn-primary">Check Out</button>
        </form>

</div>
</div>
<?php endif; ?>
<?php /**PATH C:\laragon\www\module3\hoc-lai-m3\Project\resources\views/components/cart_show.blade.php ENDPATH**/ ?>