<div class="dash-nav dash-nav-dark">
    <header>
        <a href="#!" class="menu-toggle">
            <i class="fas fa-bars"></i>
        </a>
        <a href="<?php echo e(route('dashboard')); ?>" class="easion-logo"><i class="fas fa-sun"></i> <span>TMH</span></a>
    </header>
    <nav class="dash-nav-list">
        <a href="<?php echo e(route('dashboard')); ?>" class="dash-nav-item">
            <i class="fas fa-home"></i> <?php echo e(__('lang.routename.dashboard')); ?></a>
        <div class="dash-nav-dropdown">
            <a href="<?php echo e(route('category.index')); ?>" class="dash-nav-item dash">
                <i class="fas fa-chart-bar"></i> <?php echo e(__('lang.routename.category')); ?> </a>
            <div class="dash-nav-dropdown-menu">
                
            </div>
        </div>
        <div class="dash-nav-dropdown ">
            <a href="<?php echo e(route('product.index')); ?>" class="dash-nav-item dash">
                <i class="fas fa-cube"></i> <?php echo e(__('lang.routename.product')); ?> </a>
        </div>
        
        <div class="dash-nav-dropdown">
            <a href="#" class="dash-nav-item dash-nav-dropdown-toggle">
                <i class="fas fa-cube"></i><?php echo e(__('lang.routename.customer')); ?></a>
            <div class="dash-nav-dropdown-menu">
                <i class="fas fa-file"></i>  <a href="<?php echo e(route('customer.index')); ?>" class="dash-nav-dropdown-item"><?php echo e(__('lang.routename.customer-list')); ?></a>
                <i class="fas fa-file"></i> <a href="<?php echo e(route('export')); ?>" class="dash-nav-dropdown-item">File Excel</a>
            </div>
        </div>
        <div class="dash-nav-dropdown">
            <a href="<?php echo e(route('user.index')); ?>" class="dash-nav-item dash">
                <i class="fa-solid fa-users"></i><?php echo e(__('lang.routename.user')); ?></a>
        
        </div>
        <div class="dash-nav-dropdown">
            <a href="<?php echo e(route('role.index')); ?>" class="dash-nav-item dash">
                <i class="fas fa-info"></i> <?php echo e(__('lang.routename.role')); ?> </a>
       
        </div>
        <div class="dash-nav-dropdown">
            <a href="<?php echo e(route('permissions.create')); ?>" class="dash-nav-item dash">
                <i class="fas fa-info"></i>Dữ liệu permission</a>
        
        </div>
        <div class="dash-nav-dropdown">
            <a href="<?php echo e(route('order.index')); ?>" class="dash-nav-item dash">
                <i class="fas fa-info"></i>Order</a>
        
        </div>
    </nav>
</div><?php /**PATH C:\laragon\www\module3\hoc-lai-m3\Project\resources\views/admin/layouts/sidebar.blade.php ENDPATH**/ ?>